import { Save, Mail, Bell, Shield } from 'lucide-react';

export const SettingsPage = () => {
  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-1 h-1 bg-indigo-500 rounded-full" />
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
            System Configuration
          </h3>
          <div className="flex-1 h-px bg-[#212733]" />
        </div>

        <div className="card-dark p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-slate-500" />
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Email Alerts</label>
                <p className="text-[10px] text-slate-600 font-bold">Receive notifications on critical failure</p>
              </div>
            </div>
            <input 
              type="text" 
              placeholder="admin@factory.com"
              className="w-[300px] bg-[#0B0E14] border border-[#212733] text-[11px] font-bold text-slate-300 px-4 py-2 rounded-lg outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-slate-500" />
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Notification Sound</label>
                <p className="text-[10px] text-slate-600 font-bold">Alert sound for new interventions</p>
              </div>
            </div>
            <select 
              className="w-[300px] bg-[#0B0E14] border border-[#212733] text-[11px] font-bold text-slate-300 px-4 py-2 rounded-lg outline-none focus:border-indigo-500 transition-colors"
            >
              <option>Default Alert</option>
              <option>Industrial Siren</option>
              <option>None</option>
            </select>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-slate-500" />
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Security Mode</label>
                <p className="text-[10px] text-slate-600 font-bold">RFID + QR validation requirement</p>
              </div>
            </div>
            <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer">
              <div className="w-4 h-4 bg-white rounded-full absolute right-1 top-1" />
            </div>
          </div>

          <div className="flex justify-end pt-4">
             <button className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-lg text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/10">
               <Save className="w-4 h-4" />
               Save Changes
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};
