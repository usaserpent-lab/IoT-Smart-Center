import axios from 'axios';
import type { 
  ApiResponse, 
  Machine, 
  Technician, 
  Intervention, 
  MachineEvent, 
  Reports,
  TechnicianRanking,
  StartInterventionRequest,
  EndInterventionRequest,
  LoginRequest
} from '../types';

// ============================================
// API CONFIGURATION
// ============================================

const NODE_RED_BASE_URL = import.meta.env.VITE_NODE_RED_URL || 'http://localhost:1880';

const api = axios.create({
  baseURL: NODE_RED_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('[API Error]', error.response?.status, error.message);
    return Promise.reject(error);
  }
);

// ============================================
// AUTHENTICATION SERVICE
// ============================================

export const authService = {
  login: async (credentials: LoginRequest) => {
    // TODO: Connect to Node-RED auth endpoint
    // For now, simple validation
    if (credentials.username === 'PFE26' && credentials.password === 'PFE2026') {
      const token = btoa(`${credentials.username}:${Date.now()}`);
      localStorage.setItem('auth_token', token);
      return { success: true, token };
    }
    throw new Error('Invalid credentials');
  },

  logout: async () => {
    localStorage.removeItem('auth_token');
    // TODO: Call Node-RED logout endpoint
    return { success: true };
  },

  isAuthenticated: () => {
    return !!localStorage.getItem('auth_token');
  },
};

// ============================================
// MACHINE SERVICE
// ============================================

export const machineService = {
  getStatus: async (): Promise<ApiResponse<Machine>> => {
    try {
      const response = await api.get<ApiResponse<Machine>>('/api/machine/status');
      return response.data;
    } catch (error) {
      // Mock data for development
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: {
          id: 'M1',
          name: 'Machine M1',
          state: 'RUNNING',
          state_duration: 0,
          last_update: new Date().toISOString(),
          location: 'factory/machine1',
        },
      };
    }
  },

  getHistory: async (limit = 50): Promise<ApiResponse<MachineEvent[]>> => {
    try {
      const response = await api.get<ApiResponse<MachineEvent[]>>(`/api/machine/history?limit=${limit}`);
      return response.data;
    } catch (error) {
      // Mock data
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [],
      };
    }
  },
};

// ============================================
// INTERVENTION SERVICE
// ============================================

export const interventionService = {
  start: async (request: StartInterventionRequest): Promise<ApiResponse<Intervention>> => {
    try {
      const response = await api.post<ApiResponse<Intervention>>('/api/intervention/start', request);
      return response.data;
    } catch (error: any) {
      // Mock for development - simulate success
      return {
        success: true,
        message: 'Intervention started (mock)',
        timestamp: new Date().toISOString(),
        data: {
          id: `INT-${Date.now()}`,
          machine_id: request.machine_id,
          machine_name: 'Machine M1',
          technician_id: 'T1',
          technician_name: 'Technician',
          technician_uid: request.qr_uid,
          start_time: new Date().toISOString(),
          status: 'active',
          mode: 'app',
        },
      };
    }
  },

  end: async (request: EndInterventionRequest): Promise<ApiResponse<Intervention>> => {
    try {
      const response = await api.post<ApiResponse<Intervention>>('/api/intervention/end', request);
      return response.data;
    } catch (error) {
      // Mock for development
      return {
        success: true,
        message: 'Intervention ended (mock)',
        timestamp: new Date().toISOString(),
        data: {} as Intervention,
      };
    }
  },

  getActive: async (): Promise<ApiResponse<Intervention | null>> => {
    try {
      const response = await api.get<ApiResponse<Intervention | null>>('/api/intervention/active');
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: null,
      };
    }
  },
};

// ============================================
// TECHNICIAN SERVICE
// ============================================

export const technicianService = {
  getAll: async (): Promise<ApiResponse<Technician[]>> => {
    try {
      const response = await api.get<ApiResponse<Technician[]>>('/api/technicians');
      return response.data;
    } catch (error) {
      // Mock data for development
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [
          { id: '1', name: 'Ahmed', role: 'Technician', rfid_uid: '37EECE86', qr_uid: '37EECE86', status: 'Available', interventions_count: 0, escalations_count: 0, successful_repairs: 0, avatar: '👤' },
          { id: '2', name: 'Aziz', role: 'Technician', rfid_uid: '4711CFB6', qr_uid: '4711CFB6', status: 'Available', interventions_count: 0, escalations_count: 0, successful_repairs: 0, avatar: '👤' },
          { id: '3', name: 'Chef Ligne', role: 'Line Lead', rfid_uid: 'D455D886', qr_uid: 'D455D886', status: 'Available', interventions_count: 0, escalations_count: 0, successful_repairs: 0, avatar: '👔' },
          { id: '4', name: 'Chef Atelier', role: 'Workshop Lead', rfid_uid: '86EC12BF', qr_uid: '86EC12BF', status: 'Available', interventions_count: 0, escalations_count: 0, successful_repairs: 0, avatar: '💼' },
        ],
      };
    }
  },

  getProfile: async (uid: string): Promise<ApiResponse<Technician>> => {
    try {
      const response = await api.get<ApiResponse<Technician>>(`/api/technicians/${uid}`);
      return response.data;
    } catch (error) {
      throw new Error('Technician not found');
    }
  },

  getRanking: async (): Promise<ApiResponse<TechnicianRanking[]>> => {
    try {
      const response = await api.get<ApiResponse<TechnicianRanking[]>>('/api/technicians/ranking');
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [],
      };
    }
  },

  getHistory: async (uid: string): Promise<ApiResponse<Intervention[]>> => {
    try {
      const response = await api.get<ApiResponse<Intervention[]>>(`/api/technicians/${uid}/history`);
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [],
      };
    }
  },
};

// ============================================
// REPORTS SERVICE
// ============================================

export const reportsService = {
  getDashboard: async (): Promise<ApiResponse<Reports>> => {
    try {
      const response = await api.get<ApiResponse<Reports>>('/api/reports');
      return response.data;
    } catch (error) {
      // Mock data
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: {
          machine_failures: 0,
          successful_repairs: 0,
          escalations: 0,
          maintenance_starts: 0,
          critical_events: 0,
          running_machines: 1,
          maintenance_machines: 0,
          technicians_available: 4,
        },
      };
    }
  },

  getDaily: async (date?: string): Promise<ApiResponse<any>> => {
    try {
      const response = await api.get<ApiResponse<any>>('/api/reports/daily', {
        params: { date },
      });
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: {},
      };
    }
  },
};

// ============================================
// HISTORY SERVICE
// ============================================

export const historyService = {
  getMachineHistory: async (machineId?: string, limit = 50): Promise<ApiResponse<MachineEvent[]>> => {
    try {
      const response = await api.get<ApiResponse<MachineEvent[]>>('/api/history/machine', {
        params: { machine_id: machineId, limit },
      });
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [],
      };
    }
  },

  getTechnicianHistory: async (technicianUid?: string, limit = 50): Promise<ApiResponse<Intervention[]>> => {
    try {
      const response = await api.get<ApiResponse<Intervention[]>>('/api/history/technician', {
        params: { technician_uid: technicianUid, limit },
      });
      return response.data;
    } catch (error) {
      return {
        success: true,
        timestamp: new Date().toISOString(),
        data: [],
      };
    }
  },
};

export default api;
